package com.isil.pe;


import java.util.*;

public class GrafoCampus {

    // Ubicaciones del campus
    static String[] ubicaciones = {
            "Entrada principal",  // A = 0
            "Biblioteca",         // B = 1
            "Laboratorio",        // C = 2
            "Cafeteria",          // D = 3
            "Aula",               // E = 4
            "Auditorio"           // F = 5
    };

    // Matriz de adyacencia: distancias en metros
    static int[][] grafo = {
            {0, 120, 150, 0, 0, 0},
            {120, 0, 0, 80, 0, 0},
            {150, 0, 0, 60, 0, 0},
            {0, 80, 60, 0, 50, 0},
            {0, 0, 0, 50, 0, 100},
            {0, 0, 0, 0, 100, 0}
    };

    // Heuristica estimada hasta el auditorio
    static int[] heuristica = {300, 220, 210, 150, 100, 0};

    // =====================================
    // DFS: BUSQUEDA EN PROFUNDIDAD
    // =====================================

    public static void DFS(int actual, boolean[] visitado) {

        visitado[actual] = true;

        System.out.println("Visitando: " + ubicaciones[actual]);

        for (int i = 0; i < ubicaciones.length; i++) {

            if (grafo[actual][i] > 0 && !visitado[i]) {
                DFS(i, visitado);
            }
        }
    }

    // =====================================
    // BFS: BUSQUEDA EN ANCHURA
    // =====================================

    public static void BFS(int inicio, int destino) {

        boolean[] visitado = new boolean[ubicaciones.length];
        int[] anterior = new int[ubicaciones.length];

        Arrays.fill(anterior, -1);

        Queue<Integer> cola = new LinkedList<>();

        cola.add(inicio);
        visitado[inicio] = true;

        while (!cola.isEmpty()) {

            int actual = cola.poll();

            if (actual == destino) {
                break;
            }

            for (int i = 0; i < ubicaciones.length; i++) {

                if (grafo[actual][i] > 0 && !visitado[i]) {

                    visitado[i] = true;
                    anterior[i] = actual;
                    cola.add(i);
                }
            }
        }

        if (!visitado[destino]) {
            System.out.println("No existe una ruta.");
            return;
        }

        List<Integer> ruta = new ArrayList<>();

        for (int i = destino; i != -1; i = anterior[i]) {
            ruta.add(i);
        }

        Collections.reverse(ruta);

        System.out.println("Ruta encontrada por BFS:");
        mostrarRuta(ruta);
    }

    // =====================================
    // A*: BUSQUEDA HEURISTICA
    // =====================================

    static class Nodo {
        int id;
        int costo;

        Nodo(int id, int costo) {
            this.id = id;
            this.costo = costo;
        }
    }

    public static void AEstrella(int inicio, int destino) {

        int n = ubicaciones.length;

        int[] costoReal = new int[n];
        int[] anterior = new int[n];

        boolean[] visitado = new boolean[n];

        Arrays.fill(costoReal, Integer.MAX_VALUE);
        Arrays.fill(anterior, -1);

        PriorityQueue<Nodo> abiertos =
                new PriorityQueue<>(
                        Comparator.comparingInt(a -> a.costo)
                );

        costoReal[inicio] = 0;

        abiertos.add(new Nodo(inicio, heuristica[inicio]));

        while (!abiertos.isEmpty()) {

            Nodo nodo = abiertos.poll();
            int actual = nodo.id;

            if (visitado[actual]) {
                continue;
            }

            visitado[actual] = true;

            if (actual == destino) {
                break;
            }

            for (int i = 0; i < n; i++) {

                if (grafo[actual][i] > 0 && !visitado[i]) {

                    int nuevoCosto =
                            costoReal[actual] + grafo[actual][i];

                    if (nuevoCosto < costoReal[i]) {

                        costoReal[i] = nuevoCosto;
                        anterior[i] = actual;

                        int f = nuevoCosto + heuristica[i];

                        abiertos.add(new Nodo(i, f));
                    }
                }
            }
        }

        if (costoReal[destino] == Integer.MAX_VALUE) {
            System.out.println("No existe una ruta.");
            return;
        }

        List<Integer> ruta = new ArrayList<>();

        for (int i = destino; i != -1; i = anterior[i]) {
            ruta.add(i);
        }

        Collections.reverse(ruta);

        System.out.println("Ruta encontrada por A*:");
        mostrarRuta(ruta);

        System.out.println("Distancia total: "
                + costoReal[destino] + " metros");
    }

    // =====================================
    // MOSTRAR RUTA
    // =====================================

    private static void mostrarRuta(List<Integer> ruta) {

        for (int i = 0; i < ruta.size(); i++) {

            System.out.print(ubicaciones[ruta.get(i)]);

            if (i < ruta.size() - 1) {
                System.out.print(" -> ");
            }
        }

        System.out.println();
    }

    // =====================================
    // ACTIVADOR DE LOS TRES ALGORITMOS
    // =====================================

    public static void ejecutarDemostracion() {

        System.out.println("================================");
        System.out.println("   SISTEMA DE ORIENTACION");
        System.out.println("          DEL CAMPUS");
        System.out.println("================================");

        System.out.println("\n1. BUSQUEDA DFS");

        boolean[] visitado = new boolean[ubicaciones.length];

        DFS(0, visitado);

        System.out.println("\n2. BUSQUEDA BFS");

        BFS(0, 5);

        System.out.println("\n3. BUSQUEDA A*");

        AEstrella(0, 5);
    }

    // Punto de entrada para ejecutar el programa
    public static void main(String[] args) {

        ejecutarDemostracion();

    }
}

