package com.isil.pe;


public class OrdenamientoRecursivo {

    // Clase para representar las ubicaciones del campus
    public static class Ubicacion {
        String nombre;
        int distancia;

        public Ubicacion(String nombre, int distancia) {
            this.nombre = nombre;
            this.distancia = distancia;
        }
    }

    // Metodo principal de ordenamiento (sin main)
    public static void ordenarUbicaciones(Ubicacion[] ubicaciones) {
        Ubicacion[] auxiliar = new Ubicacion[ubicaciones.length];

        mergeSort(ubicaciones, auxiliar, 0, ubicaciones.length - 1);
    }

    // Metodo recursivo Merge Sort
    private static void mergeSort(Ubicacion[] datos,
                                  Ubicacion[] auxiliar,
                                  int inicio, int fin) {

        if (inicio >= fin) {
            return;
        }

        int medio = (inicio + fin) / 2;

        // Dividir el conjunto en dos partes
        mergeSort(datos, auxiliar, inicio, medio);
        mergeSort(datos, auxiliar, medio + 1, fin);

        // Combinar las partes ordenadas
        mezclar(datos, auxiliar, inicio, medio, fin);
    }

    // Metodo para combinar y ordenar los datos
    private static void mezclar(Ubicacion[] datos,
                                Ubicacion[] auxiliar,
                                int inicio, int medio, int fin) {

        int i = inicio;
        int j = medio + 1;
        int k = inicio;

        while (i <= medio && j <= fin) {

            if (datos[i].distancia <= datos[j].distancia) {
                auxiliar[k] = datos[i];
                i++;
            } else {
                auxiliar[k] = datos[j];
                j++;
            }

            k++;
        }

        while (i <= medio) {
            auxiliar[k] = datos[i];
            i++;
            k++;
        }

        while (j <= fin) {
            auxiliar[k] = datos[j];
            j++;
            k++;
        }

        // Copiar los datos ordenados al arreglo original
        for (int x = inicio; x <= fin; x++) {
            datos[x] = auxiliar[x];
        }
    }

    public static void main (String[] args) {

        Ubicacion[] ubicaciones = {
                new Ubicacion("Laboratorio", 150),
                new Ubicacion("Biblioteca", 80),
                new Ubicacion("Cafeteria", 120),
                new Ubicacion("Aula", 50),
                new Ubicacion("Auditorio", 200)
        };

        System.out.println("UBICACIONES ANTES DEL ORDENAMIENTO:");

        for (Ubicacion u : ubicaciones) {
            System.out.println(u.nombre + " - " + u.distancia + " metros");
        }

        // Ejecutar el algoritmo recursivo
        ordenarUbicaciones(ubicaciones);

        System.out.println("\nUBICACIONES DESPUES DEL ORDENAMIENTO:");

        for (Ubicacion u : ubicaciones) {
            System.out.println(u.nombre + " - " + u.distancia + " metros");
        }

    }
}

